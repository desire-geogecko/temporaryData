INSTANCE_ID = '28f2633a-afef-4f95-8b89-e30b15662857'

import datetime
import numpy as np

from sentinelhub import WmsRequest, WcsRequest, MimeType, CRS, BBox, CustomUrlParam

betsiboka_coords_wgs84 = [33.3105316263780580,0.5061780162494490,33.3265019989460711,0.5167623897317531]


betsiboka_bbox = BBox(bbox=betsiboka_coords_wgs84, crs=CRS.WGS84)

my_evalscript = '''
var moistureIndex = (B8A-B11)/(B8A+B11);
return [moistureIndex];
'''
wcs_moisture_jan_request = WcsRequest(data_folder='landSuitability/Moisture/Jan',
                                    layer='BANDS-S2CLOUDLESS',
                                    bbox=betsiboka_bbox,
                                    time=('2018-01-01', '2018-01-31'),
                                    resx='10m', resy='10m',
                                    image_format=MimeType.TIFF_d32f,
                                    instance_id=INSTANCE_ID,
                                    custom_url_params={CustomUrlParam.EVALSCRIPT: my_evalscript})                                    

wcs_moisture_jan_imgs = wcs_moisture_jan_request.get_data(save_data=True)

wcs_moisture_feb_request = WcsRequest(data_folder='landSuitability/Moisture/Feb',
                                    layer='BANDS-S2CLOUDLESS',
                                    bbox=betsiboka_bbox,
                                    time=('2018-02-01', '2018-02-28'),
                                    resx='10m', resy='10m',
                                    image_format=MimeType.TIFF_d32f,
                                    instance_id=INSTANCE_ID,
                                    custom_url_params={CustomUrlParam.EVALSCRIPT: my_evalscript})                                    

wcs_moisture_feb_imgs = wcs_moisture_feb_request.get_data(save_data=True)

wcs_moisture_mar_request = WcsRequest(data_folder='landSuitability/Moisture/Mar',
                                    layer='BANDS-S2CLOUDLESS',
                                    bbox=betsiboka_bbox,
                                    time=('2018-03-01', '2018-03-31'),
                                    resx='10m', resy='10m',
                                    image_format=MimeType.TIFF_d32f,
                                    instance_id=INSTANCE_ID,
                                    custom_url_params={CustomUrlParam.EVALSCRIPT: my_evalscript})                                    

wcs_moisture_mar_imgs = wcs_moisture_mar_request.get_data(save_data=True)

wcs_moisture_apr_request = WcsRequest(data_folder='landSuitability/Moisture/Apr',
                                    layer='BANDS-S2CLOUDLESS',
                                    bbox=betsiboka_bbox,
                                    time=('2018-04-01', '2018-04-30'),
                                    resx='10m', resy='10m',
                                    image_format=MimeType.TIFF_d32f,
                                    instance_id=INSTANCE_ID,
                                    custom_url_params={CustomUrlParam.EVALSCRIPT: my_evalscript})                                    

wcs_moisture_apr_imgs = wcs_moisture_apr_request.get_data(save_data=True)

wcs_moisture_may_request = WcsRequest(data_folder='landSuitability/Moisture/May',
                                    layer='BANDS-S2CLOUDLESS',
                                    bbox=betsiboka_bbox,
                                    time=('2018-05-01', '2018-05-31'),
                                    resx='10m', resy='10m',
                                    image_format=MimeType.TIFF_d32f,
                                    instance_id=INSTANCE_ID,
                                    custom_url_params={CustomUrlParam.EVALSCRIPT: my_evalscript})                                    

wcs_moisture_may_imgs = wcs_moisture_may_request.get_data(save_data=True)

wcs_moisture_jun_request = WcsRequest(data_folder='landSuitability/Moisture/Jun',
                                    layer='BANDS-S2CLOUDLESS',
                                    bbox=betsiboka_bbox,
                                    time=('2018-06-01', '2018-06-30'),
                                    resx='10m', resy='10m',
                                    image_format=MimeType.TIFF_d32f,
                                    instance_id=INSTANCE_ID,
                                    custom_url_params={CustomUrlParam.EVALSCRIPT: my_evalscript})                                    

wcs_moisture_jun_imgs = wcs_moisture_jun_request.get_data(save_data=True)

wcs_moisture_jul_request = WcsRequest(data_folder='landSuitability/Moisture/Jul',
                                    layer='BANDS-S2CLOUDLESS',
                                    bbox=betsiboka_bbox,
                                    time=('2018-07-01', '2018-07-31'),
                                    resx='10m', resy='10m',
                                    image_format=MimeType.TIFF_d32f,
                                    instance_id=INSTANCE_ID,
                                    custom_url_params={CustomUrlParam.EVALSCRIPT: my_evalscript})                                    

wcs_moisture_jul_imgs = wcs_moisture_jul_request.get_data(save_data=True)

wcs_moisture_aug_request = WcsRequest(data_folder='landSuitability/Moisture/Aug',
                                    layer='BANDS-S2CLOUDLESS',
                                    bbox=betsiboka_bbox,
                                    time=('2018-08-01', '2018-08-31'),
                                    resx='10m', resy='10m',
                                    image_format=MimeType.TIFF_d32f,
                                    instance_id=INSTANCE_ID,
                                    custom_url_params={CustomUrlParam.EVALSCRIPT: my_evalscript})                                    

wcs_moisture_aug_imgs = wcs_moisture_aug_request.get_data(save_data=True)

wcs_moisture_sep_request = WcsRequest(data_folder='landSuitability/Moisture/Sep',
                                    layer='BANDS-S2CLOUDLESS',
                                    bbox=betsiboka_bbox,
                                    time=('2018-09-01', '2018-09-30'),
                                    resx='10m', resy='10m',
                                    image_format=MimeType.TIFF_d32f,
                                    instance_id=INSTANCE_ID,
                                    custom_url_params={CustomUrlParam.EVALSCRIPT: my_evalscript})                                    

wcs_moisture_sep_imgs = wcs_moisture_sep_request.get_data(save_data=True)

wcs_moisture_oct_request = WcsRequest(data_folder='landSuitability/Moisture/Oct',
                                    layer='BANDS-S2CLOUDLESS',
                                    bbox=betsiboka_bbox,
                                    time=('2018-10-01', '2018-10-31'),
                                    resx='10m', resy='10m',
                                    image_format=MimeType.TIFF_d32f,
                                    instance_id=INSTANCE_ID,
                                    custom_url_params={CustomUrlParam.EVALSCRIPT: my_evalscript})                                    

wcs_moisture_oct_imgs = wcs_moisture_oct_request.get_data(save_data=True)

wcs_moisture_nov_request = WcsRequest(data_folder='landSuitability/Moisture/Nov',
                                    layer='BANDS-S2CLOUDLESS',
                                    bbox=betsiboka_bbox,
                                    time=('2018-11-01', '2018-11-30'),
                                    resx='10m', resy='10m',
                                    image_format=MimeType.TIFF_d32f,
                                    instance_id=INSTANCE_ID,
                                    custom_url_params={CustomUrlParam.EVALSCRIPT: my_evalscript})                                    

wcs_moisture_nov_imgs = wcs_moisture_nov_request.get_data(save_data=True)

wcs_moisture_dec_request = WcsRequest(data_folder='landSuitability/Moisture/Dec',
                                    layer='BANDS-S2CLOUDLESS',
                                    bbox=betsiboka_bbox,
                                    time=('2018-12-01', '2018-12-31'),
                                    resx='10m', resy='10m',
                                    image_format=MimeType.TIFF_d32f,
                                    instance_id=INSTANCE_ID,
                                    custom_url_params={CustomUrlParam.EVALSCRIPT: my_evalscript})                                    

wcs_moisture_dec_imgs = wcs_moisture_dec_request.get_data(save_data=True)