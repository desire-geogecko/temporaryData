INSTANCE_ID = '28f2633a-afef-4f95-8b89-e30b15662857'

import glob
import os
import subprocess
import datetime
import numpy as np

from sentinelhub import WmsRequest, WcsRequest, MimeType, CRS, BBox, CustomUrlParam


folder = r"C:/Users/Desire/IdeaProjects/PROJECTS/Piets_Updates_Sinergise/Lukulu/cover/"
folder1 = r"C:/Users/Desire/IdeaProjects/PROJECTS/Piets_Updates_Sinergise/Lukulu/cover/newData/"
folder2 = r"C:/Users/Desire/IdeaProjects/PROJECTS/Piets_Updates_Sinergise/Lukulu/cover/HostedFiles/"
folder3 = r"C:/Users/Desire/IdeaProjects/PROJECTS/Piets_Updates_Sinergise/Lukulu/cover/Differences/"
osgeopath = r"C:/Program Files/QGIS 3.6/OSGeo4W.bat"

os.chdir(folder)

Lukulu_coords_wgs84 = [30.9115461120000496,-10.3336870749999505,30.9658407650000562,-10.3048367779999772]


Lukulu_bbox = BBox(bbox=Lukulu_coords_wgs84, crs=CRS.WGS84)

today = datetime.date.today()

three_month = datetime.date.today() - datetime.timedelta(3*365/12)



my_evalscript = '''
var ndvi = (B08-B04)/(B08+B04);
return [ndvi];
'''

# wcs_ndvi_jan_request = WcsRequest(data_folder='newData',
#                                     layer='BANDS-S2CLOUDLESS',
#                                     bbox=Lukulu_bbox,
#                                     time=('2015-01-01', today),
#                                     resx='10m', resy='10m',
#                                     image_format=MimeType.TIFF_d32f,
#                                     instance_id=INSTANCE_ID,
#                                     custom_url_params={CustomUrlParam.EVALSCRIPT: my_evalscript})                                    

# wcs_ndvi_jan_imgs = wcs_ndvi_jan_request.get_data(save_data=True)

# for filename in os.listdir(folder1):
#     os.chdir(folder1)
#     os.rename(filename, "Lukulu"+filename[106:])


# for root, dirs, filenames in os.walk(folder1):

#     pathiter = (os.path.join(root, filename)
#     for root, _, filenames in os.walk(folder1)
#     for filename in filenames
# )
# for path in pathiter:
#     newname =  path.replace('_10mX10m_EvalScript_varndvi=(B08-B04)(B08+B04)return[ndvi]_tiff_depth=32f.tiff', '.tiff')
#     if newname != path:
#         os.rename(path,newname)

#     paths = (os.path.join(root, filename)
#     for root, _, filenames in os.walk(folder1)
#     for filename in filenames)

for filename in os.listdir(folder1):
    os.chdir(folder1)
    newFilename = filename.replace('-','')
    os.rename(filename, newFilename[:15]+'.tif')

for filename in os.listdir(folder1):
    os.chdir(folder1)
    print(filename)
    for filenameElse in os.listdir(folder1):
        command = "\"C:\Program Files\QGIS 3.6\OSGeo4W.bat\" gdal_calc --calc=\"A-B\" --format GTiff --type Float32 -A " + folder1 + filename + " -B " + folder1 + filenameElse + " --outfile=" + folder3 + filename + "_delta_" + filenameElse + ".tif"
        print(command)
        # shell.communicate(command)
#command = "gdal_merge.py -o landSuitability/Moisture/Year1/Jan/Jan.tif -of gtiff " + files_string

        subprocess.call(command, shell=True)
        # print(command)

