INSTANCE_ID = '28f2633a-afef-4f95-8b89-e30b15662857'

import datetime
import numpy as np

from sentinelhub import WmsRequest, WcsRequest, MimeType, CRS, BBox, CustomUrlParam

Lukulu_coords_wgs84 = [30.9115461120000496,-10.3336870749999505,30.9658407650000562,-10.3048367779999772]


Lukulu_bbox = BBox(bbox=Lukulu_coords_wgs84, crs=CRS.WGS84)

today = datetime.date.today()

three_month = datetime.date.today() - datetime.timedelta(3*365/12)

my_evalscript = '''
var ndvi = (B08-B04)/(B08+B04);
return [ndvi];
'''

wcs_ndvi_jan_request = WcsRequest(data_folder='landSuitability/NDVI/Jan',
                                    layer='BANDS-S2CLOUDLESS',
                                    bbox=Lukulu_bbox,
                                    time=('2018-01-01', '2018-01-31'),
                                    resx='10m', resy='10m',
                                    image_format=MimeType.TIFF_d32f,
                                    instance_id=INSTANCE_ID,
                                    custom_url_params={CustomUrlParam.EVALSCRIPT: my_evalscript})                                    

wcs_ndvi_jan_imgs = wcs_ndvi_jan_request.get_data(save_data=True)


# wcs_dem_request = WcsRequest(data_folder='landSuitability/DEM',
#                                     layer='DEM',
#                                     bbox=Lukulu_bbox,
#                                     resx='10m', resy='10m',
#                                     image_format=MimeType.TIFF_d32f,
#                                     instance_id=INSTANCE_ID,
#                                     custom_url_params={CustomUrlParam.SHOWLOGO: False})                                    

# wcs_dem_img = wcs_dem_request.get_data(save_data=True)